#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

import json
import os

class DataAccess(object):                                                                #Define a classe DataAccess responsável pelo acesso dos dados
    def __init__(self, file_name):                                                       #Define a função __init__ que é chamada quando uma instância da classe é criada
        self.__path = os.path.join(os.path.dirname( __file__ ), '../Data/' + file_name)  #Configura o campo do caminho para o arquivo de acordo com o nome fornecido
        self.dataBase = {}                                                               #Cria um campo dataBase para receber o dicionário dos dados
                                                                                         
    def saveChanges(self):                                                               #Define o método responsável por salvar os dados do dicinário no arquivo
         with open(self.__path, 'w', encoding='utf-8') as handle:                        #Abre o arquivo, usando a função open, com nome 'handle'
            json.dump(self.dataBase, handle, indent = 3, ensure_ascii=False)             #Salva os dados do dicionário 'dataBase' no arquivo aberto com formatação Json
                                                                                         
    def loadData(self):                                                                  #Define o método responsável por carregar os dados do arquivo no dicionário
         if os.path.getsize(self.__path) > 0:                                            #Checa se o arquivo a ser carregado existe e contém dados, se for verdadeiro, entra no bloco
            with open(self.__path, 'r', encoding='utf-8') as handle:                     #Abre o arquivo, usando a função open, com nome 'handle'
                self.dataBase = json.load(handle)                                        #Carrega os dados do arquivo, com formatação json, para o dicionário 'dataBase'
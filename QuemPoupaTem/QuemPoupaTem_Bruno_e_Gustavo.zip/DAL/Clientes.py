#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

from DAL.DataAccess import DataAccess                                         #Importa a classe DataAccess do arquivo DataAccess.py

class Clientes:                                                               #Define a classe Clientes responsável responsável pelo acesso dos dados da base de Clientes
     class __Clientes(DataAccess):                                            #Define uma classe Singleton de mesmo nome que herda da classe DataAccess
        def __init__(self):                                                   #Define a função __init__ que é chamada quando uma instância da classe __Clientes é criada
            super().__init__('Clientes.txt')                                  #Ao iniciar a instância da classe __Clientes, 
                                                                              #inicia a classe pai, passando o nome do arquivo como parâmetro
     __instance = None                                                        #Cria um campo para receber a instância única da classe __Clientes
     
     def __init__(self):                                                      #Define a função __init__ que é chamada quando uma instância da classe Clientes é criada
         if not Clientes.__instance:                                          #Verifica se a instância única da classe __Clientes já foi criada
             Clientes.__instance = Clientes.__Clientes()                      #Se não foi criada, cria a instância da classe __Clientes
     
     def __loadDatabase(func):                                                #Define o método que é executado para alterar o comportamento de uma função passada como parâmetro
         def decorated(*args, **kwargs):                                      #Define a nova função que será retornada pelo método
             Clientes()                                                       #Inicia uma instância de Clientes para conseguir acessar a base de dados
             Clientes.__instance.loadData()                                   #Chama o método que carrega os dados do arquivo para o dicionário
             res = func(*args, **kwargs)                                      #Executa a função parâmetro, usando os argumentos passados ao chama-lá
             Clientes.__instance.saveChanges()                                #Chama o método que salva os dados do dicionário no arquivo
             return res                                                       #Retorna o resultado retornado da função parâmetro
         return decorated                                                     #Retorna a nova função com as funcionalidades que foram adicionadas

     @staticmethod                                                            #Declara o método add_cliente como um método estático da classe
     @__loadDatabase                                      #Indica que o método __loadDatabase será executado, passando o método add_cliente como parâmetro, sempre que add_cliente for chamado
     def add_cliente(cpf, nome, senha):                                       #Define a subrotina que adiciona um cliente a base de clientes.
         Clientes.__instance.dataBase[cpf] = {'Nome' : nome, 'Senha' : senha} #Insere um elemento no dicionário, usando o cpf como chave e passando como valor um dicionário com nome e senha
                                                                              
     @staticmethod                                                            #Declara o método apaga_cliente como um método estático da classe
     @__loadDatabase                                      #Indica que o método __loadDatabase será executado, passando o método apaga_cliente como parâmetro, sempre que apaga_cliente for chamado
     def apaga_cliente(cpf):                                                  #Define a subrotina que remove um cliente da base de clientes.
         Clientes.__instance.dataBase.pop(cpf, None)                          #Remove o cpf fornecido do dicionário. Se não existir, não faz nada.
                                                                              
     @staticmethod                                                            #Declara o método existe como um método estático da classe
     @__loadDatabase                                      #Indica que o método __loadDatabase será executado, passando o método existe como parâmetro, sempre que existe for chamado
     def existe(cpf):                                                         #Define a subrotina que verifica se o CPF inserido existe na base de clientes. A chave é o CPF.
         return cpf in Clientes.__instance.dataBase                           #Retorna True se o cpf informado existe nas chaves da base caso contratio retorna False.
                                                                              
     @staticmethod                                                            #Declara o método verifica_senha como um método estático da classe
     @__loadDatabase                                      #Indica que o método __loadDatabase será executado, passando o método verifica_senha como parâmetro, sempre que verifica_senha for chamado
     def verifica_senha(cpf, senha):                                          #Define a subrotina que verifica a senha fornecida com a senha na base de clientes.
         senha_db = Clientes.__instance.dataBase[cpf]['Senha']                #Pega a senha no dicionario do cliente de acordo com o cpf fornecido
         return senha == senha_db                                             #Compara a senha com a senha da base e retorna o resultado
                                                                              
     @staticmethod                                                            #Declara o método busca_nome como um método estático da classe
     @__loadDatabase                                      #Indica que o método __loadDatabase será executado, passando o método busca_nome como parâmetro, sempre que busca_nome for chamado
     def busca_nome(cpf):                                                     #Define a subrotina que busca o nome na base de clientes.
         return Clientes.__instance.dataBase[cpf]["Nome"]                     #Pega e retorna o nome no dicionario do cliente de acordo com o cpf fornecido

#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

from DAL.DataAccess import DataAccess                                                     #Importa a classe DataAccess do arquivo DataAccess.py
from Util.Utilitarios import Utilitarios                                                  #Importa a classe Utilitarios do arquivo Utilitarios.py
                                                                                          
class Transacoes:                                                                         #Define a classe Transacoes responsável responsável pelo acesso dos dados da base de transações
    class __Transacoes(DataAccess):                                                       #Define uma classe Singleton de mesmo nome que herda da classe DataAccess
        def __init__(self):                                                               #Define a função __init__ que é chamada quando uma instância da classe __Transacoes é criada
            super().__init__('Transacoes.txt')                                            #Ao iniciar a instância da classe __Transacoes, 
                                                                                          #inicia a classe pai, passando o nome do arquivo como parâmetro
    __instance = None                                                                     #Cria um campo para receber a instância única da classe __Transacoes
                                                                                          
    def __init__(self):                                                                   #Define a função __init__ que é chamada quando uma instância da classe Transacoes é criada
        if not Transacoes.__instance:                                                     #Verifica se a instância única da classe __Transacoes já foi criada
            Transacoes.__instance = Transacoes.__Transacoes()                             #Se não foi criada, cria a instância da classe __Transacoes
                                                                                          
    def __loadDatabase(func):                                                             #Define o método que é executado para alterar o comportamento de uma função passada como parâmetro
        def decorated(*args, **kwargs):                                                   #Define a nova função que será retornada pelo método
            Transacoes()                                                                  #Inicia uma instância de Transacoes para conseguir acessar a base de dados
            Transacoes.__instance.loadData()                                              #Chama o método que carrega os dados do arquivo para o dicionário
            res = func(*args, **kwargs)                                                   #Executa a função parâmetro, usando os argumentos passados ao chama-lá
            Transacoes.__instance.saveChanges()                                           #Chama o método que salva os dados do dicionário no arquivo
            return res                                                                    #Retorna o resultado retornado da função parâmetro
        return decorated                                                                  #Retorna a nova função com as funcionalidades que foram adicionadas
                                                                                          
    @staticmethod                                                                         #Declara o método add_transacao como um método estático da classe
    @__loadDatabase                                            #Indica que o método __loadDatabase será executado, passando o método add_transacao como parâmetro, sempre que add_transacao for chamado
    def add_transacao(cpf, valor, tarifa, saldo_atual):                                   #Define a subrotina que adiciona uma nova transação a base de Transações.
        count = 1                                                                         #Cria a variável para receber o índice sequencial da transação
        if cpf in Transacoes.__instance.dataBase:                                         #Verifica se o cliente já realizou alguma transação anteriormente
            count = int(max(Transacoes.__instance.dataBase[cpf], key=int)) + 1            #Se já realizou, pega o novo índice da transação
        else:                                                                             #Se o cliente ainda não realizou nenhuma transação
            Transacoes.__instance.dataBase[cpf] = {}                                      #Adiciona o cliente a base de transações, colocando como valor o um dicionário vazio
                                                                                          
        multiplicador = '+' if tarifa == 0 else '-'                                       #Verifica se é uma operação de debitar ou depositar para encontrar o sinal adequado
                                                                                          
        Transacoes.__instance.dataBase[cpf][count] = {  'Data'   : Utilitarios.getTime(), #Insere um elemento no dicionário, usando o cpf como chave 
                                                        'Sinal'  : multiplicador,         #e passando como valor um dicionário com os dados da trasação
                                                        'Valor'  : valor,                 
                                                        'Tarifa' : tarifa,                
                                                        'Saldo'  : saldo_atual  }         
                                                                                          
    @staticmethod                                                                         #Declara o método apaga_historico como um método estático da classe
    @__loadDatabase                                            #Indica que o método __loadDatabase será executado, passando o método apaga_historico como parâmetro, sempre que apaga_historico for chamado
    def apaga_historico(cpf):                                                             #Define a subrotina que remove o histórico de um cliente da base de transações.
        Transacoes.__instance.dataBase.pop(cpf, None)                                     #Remove o cpf fornecido do dicionário. Se não existir, não faz nada.
                                                                                          
    @staticmethod                                                                         #Declara o método busca_historico como um método estático da classe
    @__loadDatabase                                            #Indica que o método __loadDatabase será executado, passando o método busca_historico como parâmetro, sempre que busca_historico for chamado
    def busca_historico(cpf):                                                             #Define a subrotina que busca o histórico de um cliente na base de transações.
        return Transacoes.__instance.dataBase[cpf]                                        #Pega e retorna o histórico no dicionario de transações de acordo com o cpf fornecido
                                                                                          
                                                                                          
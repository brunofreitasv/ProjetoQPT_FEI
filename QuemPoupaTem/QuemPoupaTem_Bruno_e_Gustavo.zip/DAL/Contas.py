#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

from DAL.DataAccess import DataAccess                                                       #Importa a classe DataAccess do arquivo DataAccess.py
                                                                                            
class Contas:                                                                               #Define a classe Contas responsável responsável pelo acesso dos dados da base de Contas
    class __Contas(DataAccess):                                                             #Define uma classe Singleton de mesmo nome que herda da classe DataAccess
        def __init__(self):                                                                 #Define a função __init__ que é chamada quando uma instância da classe __Contas é criada
            super().__init__('Contas.txt')                                                  #Ao iniciar a instância da classe __Contas, 
                                                                                            #inicia a classe pai, passando o nome do arquivo como parâmetro
    __instance = None                                                                       #Cria um campo para receber a instância única da classe __Contas
                                                                                            
    def __init__(self):                                                                     #Define a função __init__ que é chamada quando uma instância da classe Contas é criada
        if not Contas.__instance:                                                           #Verifica se a instância única da classe __Contas já foi criada
            Contas.__instance = Contas.__Contas()                                           #Se não foi criada, cria a instância da classe __Contas
                                                                                            
    def __loadDatabase(func):                                                               #Define o método que é executado para alterar o comportamento de uma função passada como parâmetro
        def decorated(*args, **kwargs):                                                     #Define a nova função que será retornada pelo método
            Contas()                                                                        #Inicia uma instância de Contas para conseguir acessar a base de dados
            Contas.__instance.loadData()                                                    #Chama o método que carrega os dados do arquivo para o dicionário
            res = func(*args, **kwargs)                                                     #Executa a função parâmetro, usando os argumentos passados ao chama-lá
            Contas.__instance.saveChanges()                                                 #Chama o método que salva os dados do dicionário no arquivo
            return res                                                                      #Retorna o resultado retornado da função parâmetro
        return decorated                                                                    #Retorna a nova função com as funcionalidades que foram adicionadas
                                                                                            
    @staticmethod                                                                           #Declara o método add_conta como um método estático da classe
    @__loadDatabase                                                  #Indica que o método __loadDatabase será executado, passando o método add_conta como parâmetro, sempre que add_conta for chamado
    def add_conta(cpf, tipo, saldo_inicial):                                                #Define a subrotina que adiciona uma nova conta a base de contas.
        Contas.__instance.dataBase[cpf] = {'Tipo de conta' : tipo, 'Saldo' : saldo_inicial} #Insere um elemento, usando o cpf como chave e passando como valor um dicionário com tipo de conta e nome inicial

    @staticmethod                                                                           #Declara o método apaga_conta como um método estático da classe
    @__loadDatabase                                                  #Indica que o método __loadDatabase será executado, passando o método apaga_conta como parâmetro, sempre que apaga_conta for chamado
    def apaga_conta(cpf):                                                                   #Define a subrotina que remove uma conta da base de contas.
        Contas.__instance.dataBase.pop(cpf, None)                                           #Remove o cpf fornecido do dicionário. Se não existir, não faz nada.

    @staticmethod                                                                           #Declara o método busca_tipo_conta como um método estático da classe
    @__loadDatabase                                                  #Indica que o método __loadDatabase será executado, passando o método busca_tipo_conta como parâmetro, sempre que busca_tipo_conta for chamado
    def busca_tipo_conta(cpf):                                                              #Define a subrotina que busca o tipo de conta de um cliente na base de contas.
        return Contas.__instance.dataBase[cpf]["Tipo de conta"]                             #Pega e retorna o tipo de conta no dicionario de contas de acordo com o cpf fornecido

    @staticmethod                                                                           #Declara o método busca_saldo como um método estático da classe
    @__loadDatabase                                                  #Indica que o método __loadDatabase será executado, passando o método busca_saldo como parâmetro, sempre que busca_saldo for chamado
    def busca_saldo(cpf):                                                                   #Define a subrotina que busca o saldo de um cliente na base de contas.
        return Contas.__instance.dataBase[cpf]["Saldo"]                                     #Pega e retorna o saldo no dicionario de contas de acordo com o cpf fornecido
                                                                                            
    @staticmethod                                                                           #Declara o método atualiza_saldo como um método estático da classe
    @__loadDatabase                                                  #Indica que o método __loadDatabase será executado, passando o método atualiza_saldo como parâmetro, sempre que atualiza_saldo for chamado
    def atualiza_saldo(cpf, saldo):                                                         #Define a subrotina que atualiza o valor do saldo de um cliente na base de contas.
        Contas.__instance.dataBase[cpf]["Saldo"] = saldo                                    #Atualiza o valor do Saldo de um cpf de acordo com o novo saldo passado como parâmetro
                                                                                            



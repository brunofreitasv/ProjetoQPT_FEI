#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

import keyboard
from datetime import datetime
                                                                                    
class Utilitarios(object):                                                          #Define a classe Utilitarios responsável por fornecer funções úteis
                                                                                    
    tipos_conta = { 1:"Salário", 2:"Comum", 3:"Plus" }                              #Campo da classe que define as opções de conta disponíveis
                                                                                    
    @staticmethod                                                                   #Declara o método seleciona_tipo_conta como um método estático da classe
    def seleciona_tipo_conta():                                                     #Define o método responsável por fornecer as opções de tipo conta ao usuário
        print("\nSelecione o tipo de conta e pressione a tecla correspondente:")    #Imprime a msg para selecionar o tipo de conta
        for key, value in Utilitarios.tipos_conta.items():                          #Inicia um loop pelo dicionário com as opções de tipo conta
            print("    {0} - {1}     ".format(key, value))                          #Imprime a opção do menu de acordo com a chave atual e valor do dicionário
        print("\n")                                                                 #Pula uma linha
                                                                                    
        selected = -1                                                               #Cria a variável para receber o índice da opção selecionada
        while selected not in [1, 2, 3]:                                            #Entra no loop e mantém até que o usuário pressione uma das teclas correspondentes
            if keyboard.is_pressed('1'): selected = 1                               #Verifica se o usuário pressionou a tecla 1 e, se for verdadeiro atribui valor 1 a variável de seleção
            elif keyboard.is_pressed('2'): selected = 2                             #Verifica se o usuário pressionou a tecla 2 e, se for verdadeiro atribui valor 2 a variável de seleção
            elif keyboard.is_pressed('3'): selected = 3                             #Verifica se o usuário pressionou a tecla 3 e, se for verdadeiro atribui valor 3 a variável de seleção
        keyboard.stash_state()                                                      #Limpa o estado atual do teclado
                                                                                    
        tipo = Utilitarios.tipos_conta[selected]                                    #Pega a string valor do tipo de conta de acordo com a chave do dicionário
        print("Tipo: %s" % tipo)                                                    #Imprime o tipo selecionado pelo usuário
                                                                                    
        return tipo                                                                 #Retorna o tipo de conta selecionada
                                                                                    
    @staticmethod                                                                   #Declara o método confirma como um método estático da classe
    def confirma():                                                                 #Define o método responsável pedir a confirmação do usuário para uma operação
        print("\nConfirma a operação? [y / n]\n")                                   #Imprime a msg para confirmar a operação
             
        while True:                                                                 #Entra no loop infinito
            if keyboard.is_pressed('y'):                                            #Verificar se o usuário pressionou a tecla y
                keyboard.stash_state()                                              #Limpa o estado atual do teclado
                return True                                                         #retorna verdadeiro
            elif keyboard.is_pressed('n'):                                          #Verificar se o usuário pressionou a tecla n
                keyboard.stash_state()                                              #Limpa o estado atual do teclado
                return False                                                        #retorna falso
                                                                                    
    @staticmethod                                                                   #Declara o método calcula_novo_saldo_tarifa como um método estático da classe
    def calcula_novo_saldo_tarifa(tipo_conta, saldo, valor):                        #Define o método responsável por calcular o novo saldo e a tarifa de acordo com
                                                                                    #o saldo atual, o valor a ser debitado e o tipo de conta
        fator = {                                                                   #Switch expression para pegar o fator da tarifa de acordo com o tipo de conta
                   Utilitarios.tipos_conta[1] : 0.05,                               
                   Utilitarios.tipos_conta[2] : 0.03,                               
                   Utilitarios.tipos_conta[3] : 0.01                                
                }[tipo_conta]                                                       
                                                                                    
        limite = {                                                                  #Switch expression para pegar o limite da conta de acordo com o tipo de conta
                   Utilitarios.tipos_conta[1] : 0.00,                               
                   Utilitarios.tipos_conta[2] : -500.00,                            
                   Utilitarios.tipos_conta[3] : -5000.00                            
                 }[tipo_conta]                                                      
                                                                                    
        tarifa = round(valor*fator, 2)                                              #Calcula a tarifa, usando o fator selecionado
        novo_saldo = round(saldo - valor*(1 + fator), 2)                            #Calcula o novo saldo, usando o fator selecionado
                                                                                    
        if novo_saldo < limite:                                                     #Verifica se o novo saldo é menor que o limite da conta, se for entra no bloco
            print("\n{0}\nSaldo da conta não pode ficar inferior a R${1:.2f}\n"     #Imprime a msg informando que houve falha ao debitar
                  .format("Falha ao debitar! Saldo insuficiente!", limite))         
            return False, None, None                                                #Retorna Falso como sucesso da operação e nulo para valor do novo saldo e tarifa
                                                                                    #Se não executar o bloco anterior, continua a subrotina
        return True, novo_saldo, tarifa                                             #Retorna True como sucesso da operação e valor do novo saldo e tarifa
                                                                                    
    @staticmethod                                                                   #Declara o método getTime como um método estático da classe
    def getTime():                                                                  #Define o método que é responsável por retornar a data e tempo atual como uma string
        return datetime.today().strftime("%d/%m/%Y %I:%M:%S %p")                    #Retorna data e tempo atual como uma string no formato '%d/%m/%Y %I:%M:%S %p'
                                                                                    
    @staticmethod                                                                   #Declara o método valida_cpf como um método estático da classe
    def valida_cpf(cpf):                                                            #Define o método responsável por validar o cpf fornecido pelo usuário
        if not cpf.isdecimal() or len(cpf) != 11:                                   #Verifica se o cpf definido pode ser convertido para decimal e se possui 11 digitos
            print("\nCPF inválido! Deve conter apenas números e 11 digitos!\n")     #Imprime msg de cpf inválido, caso a condição verificada seja verdadeira
            return False                                                            #Retorna Falso para cpf válido
        return True                                                                 #Se não executar o bloco anterior, retorna verdadeiro
                                                                                    
    @staticmethod                                                                   #Declara o método valida_float como um método estático da classe
    def valida_float(string):                                                       #Define o método responsável por validar se o valor fornecido é realmente numérico
        try:                                                                        #Entra em um bloco para tentar executar uma operação
            return True, float(string)                                              #Tenta converter o valor para float e retorna a tuple True, Valor se conseguir
        except ValueError:                                                          #Caso ocorra um erro na conversão, pega o erro e executa o bloco a seguir
            print("\nValor inválido! Deve ser um número decimal!\n")                #Imprime que o valor é inválido pois houve erro na conversão
            return False, None                                                      #Retorna Falso e nulo para o Valor convertido
                                                                                    
    @staticmethod                                                                   #Declara o método mostra_extrato como um método estático da classe
    def mostra_extrato(cpf, nome, tipo_conta, historico):                           #Define o método responsável por imprimir o extrato de acordo com o histórico 
                                                                                    #de transações fornecido
        print("\n" * 100)                                                           #Limpa o console
        print("Nome:   {0}".format(nome))                                           #Imprime o nome do cliente passado como parâmetro
        print("CPF:    {0}".format(cpf))                                            #Imprime o CPF do cliente passado como parâmetro
        print("Conta:  {0}".format(tipo_conta))                                     #Imprime o tipo de conta do cliente passado como parâmetro
                                                                                                         
        for k, v in sorted(historico.items()):                                      #Inicia um loop pelo dicionário com do histórico ordenando-o primeiro
            print("Data: %-25s   %-1s​ %-10.2f​  ​​ Tarifa: %-10.2f​  Saldo: %-10.2f​" %  #Imprime uma transação de acordo com a chave atual e valor do dicionário
                  (v['Data'],v['Sinal'],v['Valor'],v['Tarifa'],v['Saldo']))         #Substitui os valores na string formatada
                                                                                    
        print("\n")                                                                 #Pula uma linha
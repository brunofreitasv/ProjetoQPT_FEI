#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

import keyboard                                                         #Importa o pacote externo keyboard
from Opcoes import Opcoes                                               #Importa a classe Opcoes do arquivo Opcoes.py 
                                                                        
class MainMenu:                                                         #Define a classe MainMenu
    def __init__(self, *args, **kwargs):                                #Define a função __init__ que é chamada quando uma instância da classe é criada
        self.__selected = 1                                             #Campo da instância da classe que define a opção do Menu que está selecionada
        self.menu_options = { 1:"Novo Cliente",                         #Dicionário com as opções disponiveis no Menu
                              2:"Apaga Cliente",                        
                              3:"Debita",                               
                              4:"Deposita",                             
                              5:"Saldo",                                
                              6:"Extrato",                              
                              7:"Sai" }                                 
                                                                        
    def loop(self):                                                     #Define o método responsável por fazer o loop do Menu
        while True:                                                     #Usa while para entrar em um loop infinito
            self.__get_selection()                                      #Chama o método responsável por fazer o usuário selecionar uma opção do menu
            if self.__selected == 7:                                    #Verifica se a opção selecionada é a "Sai", se for entra no bloco definido sob o if
                break                                                   #Quebra o loop infinito para encerrar a subrotina
            else:                                                       #Se a opção selecionada for diferente de "Sai", entra nesse caso
                self.__execute_action()                                 #Chama o método para executar a ação da opção selecionada
                                                                        
    def __get_selection(self):                                          #Define o método privado responsável pela seleção da opção do menu
        keyboard.add_hotkey('up', self.__up)                            #Linka o método privado __up ao evento do teclado de acionamento da tecla up
        keyboard.add_hotkey('down', self.__down)                        #Linka o método privado __down ao evento do teclado de acionamento da tecla down
        self.__show_menu()                                              #Chama o método privado responsável por exibir o menu ao usuário
        keyboard.wait('enter', True)                                    #Bloqueia o programa até que aconteça o evento do teclado de acionamento da tecla enter
        keyboard.remove_all_hotkeys()                                   #Remove todos os métodos de callback linkados aos eventos do teclado de acionamento de tecla
                                                                        
    def __show_menu(self):                                              #Define o método privado responsável por exibir o menu ao usuário
        print("\n" * 100)                                               #Limpa o console imprimindo 100 linhas vazias
        print("Escolha uma opção e pressione Enter:")                   #Imprime a msg para o usuário
        for key, value in self.menu_options.items():                    #Inicia um loop pelo dicionário com as opções do Menu
            print("{4}{2}    {0} - {1}    {3}"                          #Imprime a opção do menu de acordo com a chave e valor do dicionário
                  .format(  0 if key == 7 else key, value,              #Formarta a mensagem a ser imprimida
                         "->" if self.__selected == key else " ",       #Se a chave atual for igual a opção selecionada atualmente, adiciona a seta de seleção
                         "<-" if self.__selected == key else " ",       #Se a chave atual for igual a opção selecionada atualmente, adiciona a seta de seleção
                         "\n" if key == 7 else ""))                     #Se for a ultima opção inclui uma nova linha antes de exibir
                                                                        
    def __up(self):                                                     #Define o método, que é chamadado ao acionar a tecla up do teclado, para atualizar a opção selecionada
        if self.__selected == 1:                                        #Se a opção que atual for a primeira, entra no bloco sob o if
            self.__selected = len(self.menu_options)                    #Atualiza a opção selecionada para ser igual a ultima opção da lista
        else: self.__selected -= 1                                      #Caso a opção não seja a primeira, decrementa 1 no indice da opção selecionada
        self.__show_menu()                                              #Chama o método privado responsável por exibir o menu ao usuário
                                                                        
    def __down(self):                                                   #Define o método, que é chamadado ao acionar a tecla down do teclado, para atualizar a opção selecionada
        if self.__selected == len(self.menu_options):                   #Se a opção que atual for a ultima, entra no bloco sob o if
            self.__selected = 1                                         #Atualiza a opção selecionada para ser igual a primeira opção da lista
        else: self.__selected += 1                                      #Caso a opção não seja a ultima, incrementa 1 no indice da opção selecionada
        self.__show_menu()                                              #Chama o método privado responsável por exibir o menu ao usuário
                                                                        
    def __execute_action(self):                                         #Define o método para executar a ação da opção selecionada
        Opcoes(self.__selected).execute_action()                        #Cria uma instância da classe Opcoes, passando como parâmetro 
                                                                        #o índice da opção selecionada e executa o método para executar a ação
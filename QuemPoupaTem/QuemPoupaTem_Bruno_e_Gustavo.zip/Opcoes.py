#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

import keyboard                                                                         #Importa o pacote externo keyboard
from DAL.Clientes import Clientes                                                       #Importa a classe Clientes do arquivo Clientes.py 
from DAL.Contas import Contas                                                           #Importa a classe Contas do arquivo Contas.py 
from DAL.Transacoes import Transacoes                                                   #Importa a classe Transacoes do arquivo Transacoes.py 
from Util.Utilitarios import Utilitarios                                                #Importa a classe Utilitarios do arquivo Utilitarios.py 

class Opcoes(object):                                                                   #Define a classe classe chamada Opcoes  
    def __init__(self, option):                                                         #Define a função __init__ que é chamada quando uma instância da classe é criada
        self.__function = {                                                             #Switch expression para pegar a função de acordo a opção do menu selecionada
                            1 : self.__cria_cliente,
                            2 : self.__apaga_cliente,
                            3 : self.__debita,
                            4 : self.__deposita,
                            5 : self.__mostra_saldo,
                            6 : self.__gera_extrato
                          }[option]

    def execute_action(self):                                                           #Define a função que executa a função atrelada a ação do menu que foi selecionada
        print("\n" * 100 + "Pressione Enter para iniciar...")                           #Limpa o console e imprime msg para iniciar
        keyboard.wait('enter', True)                                                    #Aguarda o usuário apertar a tecla enter para prosseguir 

        while True:                                                                     #Usa while para entrar em um loop infinito
            for i in range(30): keyboard.send('backspace')                              #Simula o acionamento da tecla backspace para limpar a linha de comando
            keyboard.stash_state()                                                      #Limpa o estado atual do teclado
                                                                                        
            if(self.__function()):                                                      #Chama a função selecionada e verifica se o resultado da função é verdadeiro
                print("Pressione [Enter] para retornar ao menu principal!")             #Imprime a msg para retornar ao menu principal
                keyboard.wait('enter', True)                                            #Aguarda o cliente apertar a tecla enter para prosseguir 
                return                                                                  #Retorna para o menu principal
            else:                                                                       #Se o resultado da função for falso (operação mal sucedida)
                print("Pressione [s] para tentar novamente e [Esc] para retornar ao menu principal!") #Imprime questionamento ao usuário
                while True:                                                             #Entra no loop infinito
                    if keyboard.is_pressed('esc'): return                               #Verifica se o usuário pressionou a tecla esc e retorna ao menu se for verdadeiro
                    elif keyboard.is_pressed('s'):                                      #Senão Verifica se o usuário pressionou a tecla s
                        print("\n"*100)                                                 #Limpa o console
                        break                                                           #Quebra o loop
                                                                                        
    def __cria_cliente(self):                                                           #Define a função que cria um novo cliente     
        cpf = input("Digite o CPF: ")                                                   #Solicita o cpf ao usuário e armazena o CPF inserido pelo cliente 
        if Utilitarios.valida_cpf(cpf):                                                 #Chama a subrotina que verifica se o CPF é valido  
            if Clientes.existe(cpf):                                                    #Chama a subrotina que verifica se o CPF já existe na base. 
                print("CPF existente, verifique se o dado inserido está correto ou tente outra opção!\n") #Caso exista ele imprime uma mensagem de erro
            else:                                                                                         #Caso contrario ele segue com as outras informações
                nome = input("Digite o nome completo: ")                                                  #Solicita ao usuário que entre o nome do cliente

                isfloat, saldo = Utilitarios.valida_float(input("Digite o saldo inicial da conta: "))  #Chama a subrotina que verifica se o saldo inserido é valido
                if isfloat:                                                             #Usa a variável retornada pela subrotina que indica que o número é valido  
                    senha = input("Insira uma senha: ")                                 #Solicita ao usuário que entre com a senha que deseja associar ao cliente
                    tipo = Utilitarios.seleciona_tipo_conta()                           #Chama a subrotina para o cliente escolher o tipo de conta

                    if(Utilitarios.confirma()):                                         #Chama o método que pede ao usuário para confirmar a operação
                        Clientes.add_cliente(cpf , nome, senha)                         #Adiciona o novo cliente a base de clientes
                        Contas.add_conta(cpf, tipo, saldo)                              #Adiciona o novo cliente a base de contas

                        print("\n" * 100 + "Novo cliente criado com sucesso!\n")        #Limpa o console e imprime msg de sucesso
                        return True                                                     #Retorna que a operação foi bem sucedida
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __apaga_cliente(self):                                                          #Define a função que apaga o cliente 
        cpf_valido, cpf = self.__getCPF()                                               #Chama o método que solicita o CPF ao usuário e retorna se ele é valido 
        if(cpf_valido and Utilitarios.confirma()):                                      #Usa a booleana que indica que o CPF é valido e pede para a pessoa confirmar a operação 
            Clientes.apaga_cliente(cpf)                                                 #Chama a subrotina que apaga o cliente da base de clientes 
            Contas.apaga_conta(cpf)                                                     #Chama a subrotina que apaga o cliente da base de contas
            Transacoes.apaga_historico(cpf)                                             #Chama a subrotina que apaga o cliente da base de transações 

            print("\n" * 100 + "Cliente apagado com sucesso!\n")                        #Limpa o console e imprime msg de sucesso
            return True                                                                 #Retorna que a operação foi bem sucedida           
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __debita(self):                                                                 #Define a função que debita um valor da conta do cliente     
        cpf_valido, cpf = self.__getCPF()                                               #Chama o método que solicita o CPF ao usuário e retorna se ele é valido  
        if(cpf_valido):                                                                 # Chama a subrotina que verifica se o CPF existe 
            isfloat, valor = Utilitarios.valida_float(input("Qual valor deseja debitar da conta? ")) #Chama a subrotina que verifica se o saldo inserido é valido
            if isfloat:                                                                 #Usa a variável retornada pela subrotina que indica que o número é valido
                senha = input("Insira a senha: ")                                       #Solicita ao usuário que entre com a senha
                if Clientes.verifica_senha(cpf, senha):                                 #Chama função que verifica a senha inserida 
                    tipo = Contas.busca_tipo_conta(cpf)                                 #Chama a subrotina que retorna o tipo de conta do cliente
                    saldo_atual = Contas.busca_saldo(cpf)                               #Chama a subrotina que retorna o saldo atual do cliente     

                    trans_valida, n_saldo, tarif = Utilitarios.calcula_novo_saldo_tarifa(tipo, saldo_atual, valor) #Chama o método que calcula o novo saldo e a tarifa 
                                                                                        #de acordo com o saldo atual, o valor a ser debitado e o tipo de conta
                    if(trans_valida and Utilitarios.confirma()):                        #Se for uma transação possível, pede para o usuário confirmar a operação 
                        Contas.atualiza_saldo(cpf, n_saldo)                             #Chama a subrotina que atualiza o saldo da conta 
                        Transacoes.add_transacao(cpf, valor, tarif, n_saldo)            #Chama a subrotina que adiciona a transação a base de transações

                        print("\n"*100 + "O valor foi debitado da conta!\n")            #Limpa o console e imprime msg de sucesso
                        return True                                                     #Retorna que a operação foi bem sucedida 
                else:                                                                   #Se a senha fornecida não for válida
                    print("\nSenha incorreta!\n")                                       #Imprime msg de falha
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __deposita(self):                                                               #Define a função que deposita um valor na conta do cliente 
        cpf_valido, cpf = self.__getCPF()                                               #Chama o método que solicita o CPF ao usuário e retorna se ele é valido 
        if(cpf_valido):
            isfloat, valor = Utilitarios.valida_float(input("Qual valor deseja depositar na conta? ")) #Chama a subrotina que verifica se o saldo inserido é valido
            if isfloat and Utilitarios.confirma():                                      #Usa a variável retornada pela subrotina que indica que o número é valido e aguarda a confirmação da ação
                saldo_atual = Contas.busca_saldo(cpf)                                   #Chama a subrotina que retorna o saldo atual da conta 
                n_saldo = round(saldo_atual + valor, 2)                                 #Calcula o novo saldo da conta
                                                                                        
                Contas.atualiza_saldo(cpf, n_saldo)                                     #Chama a subrotina que atualiza o saldo 
                Transacoes.add_transacao(cpf, valor, 0, n_saldo)                        #Chama a subrotina que adiciona a transação a base de transações 

                print("\n"*100 + "O valor foi depositado na conta!\n")                  #Limpa o console e imprime msg de sucesso
                return True                                                             #Retorna que a operação foi bem sucedida
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __mostra_saldo(self):                                                           #Define a função que mostra o saldo do cliente
        sucesso = False                                                                 #Atribui como valor inicial 'falso' para o sucesso da operação
        cpf_valido, cpf = self.__getCPF()                                               #Chama o método que solicita o CPF ao usuário e retorna se ele é valido 
        if(cpf_valido):                                                                 #Usa a booleana retornada pela subrotina que verifica se o CPF existe
            senha = input("Insira a senha: ")                                           #Solicita a senha ao usuário    
            if Clientes.verifica_senha(cpf, senha):                                     #Chama função que verifica a senha inserida 
                print("\n"*100 + "O saldo da conta é igual a R${:.2f}\n".format(Contas.busca_saldo(cpf))) #Chama o método que busca o saldo do cliente e imprime o resultado
                return True                                                             #Retorna que a operação foi bem sucedida 
            else:                                                                       #Se a senha fornecida não for válida
                print("\nSenha incorreta!\n")                                           #Imprime msg de falha
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __gera_extrato(self):                                                           #Define a função que mostra o extrato
        cpf_valido, cpf = self.__getCPF()                                               #Chama o método que solicita o CPF ao usuário e retorna se ele é valido 
        if(cpf_valido):                                                                 #Usa a booleana retornada pela subrotina que verifica se o CPF existe  
            senha = input("Insira a senha: ")                                           #Solicita a senha ao usuário
            if Clientes.verifica_senha(cpf, senha):                                     #Chama função que verifica a senha inserida 
                Utilitarios.mostra_extrato(cpf,                                         #Chama a subrotina que mostra o extrato do cliente, tendo como parâmetros:
                            Clientes.busca_nome(cpf),                                   #Nome do cliente retornado pelo método que busca o nome
                            Contas.busca_tipo_conta(cpf),                               #Tipo de conta do cliente retornado pelo método que busca po tipo de conta
                            Transacoes.busca_historico(cpf))                            #Histórico de transações do cliente retornado pelo método que busca o histórico
                return True                                                             #Retorna verdadeiro como valor para operação bem sucedida
            else:                                                                       #Se a senha fornecida não for válida
                print("\nSenha incorreta!\n")                                           #Imprime msg de falha
        return False                                                                    #Retorna que a operação não foi bem sucedida

    def __getCPF(self):                                                                 #Define a função responsável por solicitar o CPF ao usuário e verifica se ele é valido
        cpf = input("Digite o CPF: ")                                                   #Solicita o CPF e armazena o CPF inserido pelo usuário   
        if not Clientes.existe(cpf):                                                    #Chama a subrotina que verifica se o CPF não existe na base de clientes
            print("\n" * 100 + "CPF não encontrado!\n")                                 #Se não existir limpa o console e imprime msg de erro
            return False, None                                                          #Retorna falso para CPF válido e nulo como valor do CPF
        return True, cpf                                                                #Retorna true para CPF válido e o valor entrado pelo usuário como valor do CPF
#Toda a lógica e desenvolvimento foi feito em conjunto pelos dois membros da dupla

import os, sys

main_dir = os.path.join(                                              #Pega o diretório para o pacote externo usado no projeto
           os.path.dirname(                                           
           os.path.abspath(__file__)),'ExternalPackages\keyboard')    
sys.path.insert(0, main_dir)                                          #Insere o caminho para o diretório do pacote externo ao PYTHONPATH

from Menu import MainMenu                                             #Importa a classe MainMenu do arquivo Menu.py                            
MainMenu().loop()                                                     #Cria uma instância da classe MainMenu e executa o método para iniciar o loop
